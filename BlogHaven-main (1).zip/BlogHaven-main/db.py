import mysql.connector

def get_db_connection():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",       # XAMPP default
        password="",       # leave empty if no password
        database="book_blog_mca"
    )
    return conn

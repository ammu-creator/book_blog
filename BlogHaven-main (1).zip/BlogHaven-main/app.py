import os
from flask import Flask, render_template, request, redirect, url_for, session, flash
from db import get_db_connection
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = "supersecretkey"  # session management

# ---------- File Upload Config ----------
UPLOAD_FOLDER = "static/uploads"
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif"}
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


# ----------------- Home Page -----------------
@app.route("/")
def home():
    return render_template("home.html")


# ----------------- About Page -----------------
@app.route("/about")
def about():
    return render_template("about.html")


# ----------------- Register Page -----------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        email = request.form["email"]
        password = request.form["password"]
        role = request.form["role"]

        if role == "admin":
            flash("Admins cannot register!", "danger")
            return redirect(url_for("register"))

        hashed_password = generate_password_hash(password)
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username=%s", (username,))
        if cursor.fetchone():
            flash("Username already exists!", "danger")
            cursor.close()
            conn.close()
            return redirect(url_for("register"))

        cursor.execute(
            "INSERT INTO users (username,email,password,role,status) VALUES (%s,%s,%s,%s,%s)",
            (username, email, hashed_password, role, "Active"),
        )
        conn.commit()
        cursor.close()
        conn.close()
        flash("Registration successful! Please login.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


# ----------------- Login Page -----------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        role = request.form["role"]

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE username=%s AND role=%s", (username, role))
        user = cursor.fetchone()
        cursor.close()
        conn.close()

        if user and check_password_hash(user["password"], password):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]

            if role == "admin":
                return redirect(url_for("admin_dashboard"))
            elif role == "blogger":
                return redirect(url_for("blogger_dashboard"))
            else:
                return redirect(url_for("viewer_dashboard"))
        else:
            flash("Invalid credentials!", "danger")
            return redirect(url_for("login"))

    return render_template("login.html")


# ----------------- Dashboards -----------------
@app.route("/admin/dashboard")
def admin_dashboard():
    if "role" in session and session["role"] == "admin":
        return render_template("admin_dashboard.html", username=session["username"])
    return redirect(url_for("login"))


@app.route("/blogger/dashboard")
def blogger_dashboard():
    if "role" in session and session["role"] == "blogger":
        return render_template("blogger_dashboard.html", username=session["username"])
    return redirect(url_for("login"))


@app.route("/viewer/dashboard")
def viewer_dashboard():
    if "role" in session and session["role"] == "viewer":
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM blogs ORDER BY blog_id DESC")
        blogs = cursor.fetchall()
        cursor.close()
        conn.close()
        return render_template("viewer_dashboard.html", username=session["username"], blogs=blogs)
    return redirect(url_for("login"))


# ----------------- Create Blog -----------------
@app.route("/create_blog", methods=["GET", "POST"])
def create_blog():
    if "role" not in session or session["role"] != "blogger":
        return redirect(url_for("login"))

    if request.method == "POST":
        title = request.form["title"]
        author = request.form["author"]
        content = request.form["content"]
        category = request.form["category"]

        # Handle image upload
        image_file = request.files["image"]
        image_filename = None
        if image_file and allowed_file(image_file.filename):
            image_filename = secure_filename(image_file.filename)
            image_file.save(os.path.join(app.config["UPLOAD_FOLDER"], image_filename))

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO blogs (title, author, content, category, image, blogger_id) VALUES (%s, %s, %s, %s, %s, %s)",
            (title, author, content, category, image_filename, session["user_id"]),
        )
        conn.commit()
        cursor.close()
        conn.close()
        flash("🎉 Blog created successfully!", "success")
        return redirect(url_for("my_blogs"))

    return render_template("create_blog.html")


# ----------------- My Blogs -----------------
@app.route("/my_blogs")
def my_blogs():
    if "user_id" not in session:
        return redirect(url_for("login"))

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM blogs WHERE blogger_id = %s ORDER BY blog_id DESC", (session["user_id"],))
    blogs = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template("my_blogs.html", blogs=blogs)


# ----------------- View Blog -----------------
@app.route("/view_blog/<int:blog_id>", methods=["GET", "POST"])
def view_blog(blog_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM blogs WHERE blog_id = %s", (blog_id,))
    blog = cursor.fetchone()

    if not blog:
        cursor.close()
        conn.close()
        flash("Blog not found!", "danger")
        return redirect(url_for("my_blogs"))

    # Handle new comment
    if request.method == "POST" and "comment" in request.form:
        comment = request.form["comment"]
        cursor.execute("INSERT INTO comments (blog_id, user_id, comment) VALUES (%s, %s, %s)",
                       (blog_id, session["user_id"], comment))
        conn.commit()
        flash("💬 Comment added!", "success")

    cursor.execute("""
        SELECT c.*, u.username 
        FROM comments c 
        JOIN users u ON c.user_id = u.id
        WHERE c.blog_id = %s
        ORDER BY c.created_at DESC
    """, (blog_id,))
    comments = cursor.fetchall()

    cursor.execute("SELECT AVG(rating) as avg_rating FROM ratings WHERE blog_id = %s", (blog_id,))
    avg_rating = cursor.fetchone()["avg_rating"] or 0

    cursor.close()
    conn.close()
    return render_template("view_blog.html", blog=blog, comments=comments, avg_rating=avg_rating)


# ----------------- Manage Comments -----------------
@app.route("/manage_comments")
def manage_comments():
    if "user_id" not in session or session["role"] != "blogger":
        return redirect(url_for("login"))

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT c.comment_id, c.comment, c.likes, c.created_at,
               u.username AS commenter, b.title AS blog_title
        FROM comments c
        JOIN blogs b ON c.blog_id = b.blog_id
        JOIN users u ON c.user_id = u.id
        WHERE b.blogger_id = %s
        ORDER BY c.created_at DESC
    """, (session["user_id"],))
    comments = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template("manage_comments.html", comments=comments)


# ----------------- Like Comment -----------------
@app.route("/like_comment/<int:comment_id>", methods=["POST"])
def like_comment(comment_id):
    if "user_id" not in session:
        return redirect(url_for("login"))

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM comment_likes WHERE comment_id=%s AND user_id=%s",
                   (comment_id, session["user_id"]))
    if not cursor.fetchone():
        cursor.execute("INSERT INTO comment_likes (comment_id, user_id) VALUES (%s, %s)",
                       (comment_id, session["user_id"]))
        cursor.execute("UPDATE comments SET likes = likes + 1 WHERE comment_id = %s", (comment_id,))
        conn.commit()

    cursor.close()
    conn.close()
    return redirect(url_for("manage_comments"))


# ----------------- Delete Comment -----------------
@app.route("/delete_comment/<int:comment_id>", methods=["POST"])
def delete_comment(comment_id):
    if "user_id" not in session:
        return redirect(url_for("login"))

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM comments WHERE comment_id = %s", (comment_id,))
    conn.commit()
    cursor.close()
    conn.close()
    return redirect(url_for("manage_comments"))


# ----------------- Edit Blog -----------------
@app.route("/edit_blog/<int:blog_id>", methods=["GET", "POST"])
def edit_blog(blog_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM blogs WHERE blog_id = %s", (blog_id,))
    blog = cursor.fetchone()

    if not blog:
        flash("Blog not found!", "danger")
        cursor.close()
        conn.close()
        return redirect(url_for("my_blogs"))

    if request.method == "POST":
        title = request.form["title"]
        category = request.form["category"]
        content = request.form["content"]

        cursor.execute("UPDATE blogs SET title=%s, category=%s, content=%s WHERE blog_id=%s",
                       (title, category, content, blog_id))
        conn.commit()
        cursor.close()
        conn.close()
        flash("Blog updated successfully!", "success")
        return redirect(url_for("my_blogs"))

    cursor.close()
    conn.close()
    return render_template("edit_blog.html", blog=blog)


# ----------------- Delete Blog -----------------
@app.route("/delete_blog/<int:blog_id>")
def delete_blog(blog_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM blogs WHERE blog_id = %s", (blog_id,))
    conn.commit()
    cursor.close()
    conn.close()
    flash("Blog deleted successfully!", "success")
    return redirect(url_for("my_blogs"))


# ----------------- View Others' Blogs -----------------
@app.route("/view_others_blogs")
def view_others_blogs():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM blogs ORDER BY created_at DESC")
    blogs = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template("view_others_blogs.html", blogs=blogs)


# ----------------- View Single Blog (Others) -----------------
@app.route("/blog/<int:blog_id>")
def view_blog_detail(blog_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM blogs WHERE blog_id = %s", (blog_id,))
    blog = cursor.fetchone()

    cursor.execute("""
        SELECT c.comment, u.username
        FROM comments c
        JOIN users u ON c.user_id = u.id
        WHERE c.blog_id = %s
        ORDER BY c.created_at DESC
    """, (blog_id,))
    comments = cursor.fetchall()

    cursor.execute("SELECT AVG(rating) as avg_rating, COUNT(*) as total_ratings FROM ratings WHERE blog_id = %s",
                   (blog_id,))
    rating_data = cursor.fetchone()

    blog["avg_rating"] = rating_data["avg_rating"] or 0
    blog["total_ratings"] = rating_data["total_ratings"]

    cursor.close()
    conn.close()
    return render_template("blog_detail.html", blog=blog, comments=comments)


# ----------------- Add Comment -----------------
@app.route("/add_comment/<int:blog_id>", methods=["POST"])
def add_comment(blog_id):
    if "user_id" not in session:
        return redirect(url_for("login"))

    comment = request.form["comment"]
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO comments (blog_id, user_id, comment) VALUES (%s, %s, %s)",
                   (blog_id, session["user_id"], comment))
    conn.commit()
    cursor.close()
    conn.close()
    flash("💬 Comment added!", "success")
    return redirect(url_for("view_blog_detail", blog_id=blog_id))


# ----------------- Rate Blog -----------------
@app.route("/rate_blog/<int:blog_id>", methods=["POST"])
def rate_blog(blog_id):
    if "user_id" not in session:
        return redirect(url_for("login"))

    rating = int(request.form["rating"])
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM ratings WHERE blog_id = %s AND user_id = %s",
                   (blog_id, session["user_id"]))
    existing = cursor.fetchone()
    if existing:
        cursor.execute("UPDATE ratings SET rating = %s WHERE blog_id = %s AND user_id = %s",
                       (rating, blog_id, session["user_id"]))
    else:
        cursor.execute("INSERT INTO ratings (blog_id, user_id, rating) VALUES (%s, %s, %s)",
                       (blog_id, session["user_id"], rating))

    conn.commit()
    cursor.close()
    conn.close()
    flash("⭐ Rating submitted!", "success")
    return redirect(url_for("view_blog_detail", blog_id=blog_id))


# ----------------- Edit Profile -----------------
@app.route("/edit_profile", methods=["GET", "POST"])
def edit_profile():
    if "user_id" not in session:
        return redirect(url_for("login"))

    user_id = session["user_id"]
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == "POST":
        username = request.form["username"]
        email = request.form["email"]

        cursor.execute("UPDATE users SET username=%s, email=%s WHERE id=%s", (username, email, user_id))
        conn.commit()
        flash("Profile updated successfully!", "success")
        cursor.close()
        conn.close()
        return redirect(url_for("edit_profile"))

    cursor.execute("SELECT username, email FROM users WHERE id=%s", (user_id,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()
    return render_template("edit_profile.html", user=user)


# ----------------- Admin: Manage Users -----------------
# ----------------- Admin: Manage Users -----------------
@app.route("/admin/users")
def manage_users():
    if "role" in session and session["role"] == "admin":
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT id, username, email, role, status FROM users")
        users = cursor.fetchall()
        cursor.close()
        conn.close()
        return render_template("manage_users.html", users=users, username=session["username"])
    return redirect(url_for("login"))


# ----------------- Admin: Manage Blogs -----------------
@app.route("/admin/manage_blogs")
def admin_manage_blogs():
    if "role" in session and session["role"] == "admin":
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        # Fetch blogs
        cursor.execute("""
            SELECT b.blog_id, b.title, b.content, b.category, b.image, u.username AS author, b.created_at
            FROM blogs b
            JOIN users u ON b.blogger_id = u.id
            ORDER BY b.blog_id DESC
        """)
        blogs = cursor.fetchall()
        # Ensure created_at exists for all blogs
        for blog in blogs:
            if 'created_at' not in blog or blog['created_at'] is None:
                blog['created_at'] = ''

        # Fetch comments
        cursor.execute("""
            SELECT c.comment_id, c.comment, c.blog_id, u.username AS commenter, c.created_at
            FROM comments c
            JOIN users u ON c.user_id = u.id
            ORDER BY c.comment_id DESC
        """)
        comments = cursor.fetchall()
        # Ensure created_at exists for all comments
        for comment in comments:
            if 'created_at' not in comment or comment['created_at'] is None:
                comment['created_at'] = ''

        cursor.close()
        conn.close()
        return render_template("admin_manage_blogs.html", blogs=blogs, comments=comments, username=session["username"])
    return redirect(url_for("login"))


# ----------------- Admin: Delete Blog -----------------
@app.route("/admin/delete_blog/<int:blog_id>", methods=["POST"])
def admin_delete_blog(blog_id):
    if "role" in session and session["role"] == "admin":
        conn = get_db_connection()
        cursor = conn.cursor()
        # Delete the blog
        cursor.execute("DELETE FROM blogs WHERE blog_id = %s", (blog_id,))
        # Also delete comments for that blog
        cursor.execute("DELETE FROM comments WHERE blog_id = %s", (blog_id,))
        conn.commit()
        cursor.close()
        conn.close()
        flash("Blog deleted successfully!", "success")
        return redirect(url_for("admin_manage_blogs"))
    return redirect(url_for("login"))


# ----------------- Admin: Block User -----------------
# ----------------- Admin: Block User -----------------
@app.route("/admin/block/<int:user_id>", methods=["POST"])
def block_user(user_id):
    if "role" in session and session["role"] == "admin":
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Check if user already blocked
        cursor.execute("SELECT status FROM users WHERE id=%s", (user_id,))
        user = cursor.fetchone()
        if user and user["status"] == "Blocked":
            flash("⚠️ User is already blocked!", "warning")
        else:
            cursor.execute("UPDATE users SET status='Blocked' WHERE id=%s", (user_id,))
            conn.commit()
            flash("✅ User has been blocked successfully!", "success")
        
        cursor.close()
        conn.close()
        return redirect(url_for("manage_users"))
    return redirect(url_for("login"))


# ----------------- Admin: Delete User -----------------
@app.route("/admin/delete/<int:user_id>", methods=["POST"])
def delete_user(user_id):
    if "role" in session and session["role"] == "admin":
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("DELETE FROM users WHERE id=%s", (user_id,))
        conn.commit()
        
        cursor.close()
        conn.close()
        flash("❌ User deleted successfully!", "danger")
        return redirect(url_for("manage_users"))
    return redirect(url_for("login"))


# ----------------- Logout -----------------
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))


# ----------------- Run App -----------------
if __name__ == "__main__":
    app.run(debug=True)
